<?php
return [
    'emails' => explode(',', env('ELEVATED_USERS'))
];