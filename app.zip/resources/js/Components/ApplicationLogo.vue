<template>
	<img src="/ejp.png" alt="" />
</template>
