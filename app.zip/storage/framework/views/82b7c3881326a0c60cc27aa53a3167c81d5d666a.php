<?php echo e($slot); ?>

<?php /**PATH /home/boniface-jr/Projects/jeneece/incentive-program/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>