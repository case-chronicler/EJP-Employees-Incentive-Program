<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/boniface-jr/Projects/jeneece/incentive-program/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>